﻿using FireSharp.Config;
using FireSharp.Interfaces;
using FireSharp.Response;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace booking
{
    public partial class Form1 : Form
    {
        private DateTimePicker timePicker;

        IFirebaseConfig config = new FirebaseConfig()
        {
            AuthSecret = "kxJZyHETKqnVEzdy03GnyC9cKR1B58u82g2J4NRh",
            BasePath = "https://booking-c7b97-default-rtdb.firebaseio.com/"
        };

        IFirebaseClient client;

        public Form1()
        {
            InitializeComponent();

            // Initialize the Firebase client
            client = new FireSharp.FirebaseClient(config);
            timePicker = new DateTimePicker();
            Controls.Add(timePicker);
        }

        private async void button1_Click(object sender, EventArgs e)
        {
            if (NametextBox.Text.Trim() == String.Empty)
            {
                MessageBox.Show("Please type Full Name", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                NametextBox.Focus();
                return;
            }

            UserDetail anUserDetail = new UserDetail();
            anUserDetail.id = labelid.Text;
            anUserDetail.Name = NametextBox.Text;
            anUserDetail.Email = EmailtextBox.Text;
            anUserDetail.Description = DescriptiontextBox.Text;
            anUserDetail.Contact = ContacttextBox.Text;
            anUserDetail.Date = dateTimePicker.Value.ToUniversalTime().ToString("o");
            anUserDetail.AppointmentDateTime = new DateTime(
                       dateTimePicker.Value.Year,
                       dateTimePicker.Value.Month,
                       dateTimePicker.Value.Day,
                       timePicker.Value.Hour,
                       timePicker.Value.Minute,
                       0
                   );


            if (Savebutton.Text == @"Save")
            {
                PushResponse message = await client.PushAsync("MeetingList", anUserDetail);
                HandlePushResponse(message);
            }
            else if (Savebutton.Text == @"Update")
            {
                var message = await client.UpdateAsync("MeetingList/" + anUserDetail.id, anUserDetail);
                HandleUpdateResponse(message);
            }
        }

        private void HandlePushResponse(PushResponse message)
        {
            if (message != null)
            {
                MessageBox.Show("Appointment details have been saved", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                Reset();
                GetAllMeetings();
            }
            else
            {
                MessageBox.Show("Appointment details could not be saved", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void HandleUpdateResponse(FirebaseResponse response)
        {
            if (response.StatusCode == System.Net.HttpStatusCode.OK)
            {
                MessageBox.Show("Appointment details have been updated", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                Reset();
                Savebutton.Text = "Save";
                GetAllMeetings();
            }
            else
            {
                MessageBox.Show("Appointment details could not be updated", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void Reset()
        {
            NametextBox.Clear();
            EmailtextBox.Clear();
            DescriptiontextBox.Clear();
            ContacttextBox.Clear();
            dateTimePicker.Value = DateTimePicker.MinimumDateTime;
            deletebutton.Enabled = false;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            if (Ulitily.IsCheckInternet())
            {
                GetAllMeetings();
            }
            else
            {
                MessageBox.Show("Please check your Internet Connection", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        public async void GetAllMeetings()
        {
            var data = await client.GetAsync("MeetingList");

            if (!string.IsNullOrEmpty(data.Body))
            {
                Dictionary<string, UserDetail> userdetails = data.ResultAs<Dictionary<string, UserDetail>>();

                foreach (var userdetail in userdetails)
                {
                    dataGridView.Rows.Add(
                        userdetail.Key,
                        userdetail.Value.Name,
                        userdetail.Value.Email,
                        userdetail.Value.Description,
                        userdetail.Value.Contact,
                        userdetail.Value.AppointmentDateTime.ToString("g") // Display both date and time
                    );
                }

            }
        }

        private async void dataGridView_DoubleClick(object sender, EventArgs e)
        {
            if (dataGridView.SelectedCells.Count > 0)
            {
                int selectedRowIndex = dataGridView.SelectedCells[0].RowIndex;
                string id = dataGridView.Rows[selectedRowIndex].Cells[0].Value.ToString();

                UserDetail anUserdetail = await GetMeetings(id);

                labelid.Text = anUserdetail.id;
                NametextBox.Text = anUserdetail.Name;
                EmailtextBox.Text = anUserdetail.Email;
                DescriptiontextBox.Text = anUserdetail.Description;
                ContacttextBox.Text = anUserdetail.Contact;

                DateTime parsedDate;
                if (DateTime.TryParse(anUserdetail.Date, out parsedDate))
                {
                    dateTimePicker.Value = parsedDate.ToLocalTime();  // Display in local time
                }
                else
                {
                    // Handle parsing error
                }
                Savebutton.Text = "Update";
                deletebutton.Enabled = true;
            }
        }

        public async Task<UserDetail> GetMeetings(string id)
        {
            var data = await client.GetAsync("MeetingList/" + id);
            UserDetail anUserdetail = new UserDetail();
            if (!string.IsNullOrEmpty(data.Body))
            {
                anUserdetail = data.ResultAs<UserDetail>();
                anUserdetail.id = id;
            }
            return anUserdetail;
        }

        private async void deletebutton_Click(object sender, EventArgs e)
        {
            if (dataGridView.SelectedCells.Count > 0)
            {
                int selectedRowIndex = dataGridView.SelectedCells[0].RowIndex;
                string id = dataGridView.Rows[selectedRowIndex].Cells[0].Value.ToString();

                if (
                    MessageBox.Show("Are you sure you want to delete this appointment?", "Confirm Deletion", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                 
                Reset();
                Savebutton.Text = "Save";
                GetAllMeetings();
                {
                    await DeleteMeeting(id);
                }
            }
        }

        private async Task DeleteMeeting(string id)
        {
            FirebaseResponse response = await client.DeleteAsync("MeetingList/" + id);
            if (response.StatusCode == System.Net.HttpStatusCode.OK)
            {
                MessageBox.Show("Appointment has been deleted", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                Reset();
                GetAllMeetings();
            }
            else
            {
                MessageBox.Show("Appointment deletion failed", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

    }
}
