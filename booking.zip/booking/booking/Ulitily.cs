﻿using System;
using System.Net;

namespace booking
{
    public static class Ulitily
    {
        public static bool IsCheckInternet()
        {
            try
            {
                using (var client = new WebClient())
                {
                    using (client.OpenRead(address:"http://www.google.com"))  // Corrected syntax here
                    {
                        return true;
                    }
                }
            }
            catch (Exception)
            {
                return false;
            }
        }
    }
}
